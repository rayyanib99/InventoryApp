package com.example.option1_inventoryapp_rayyanabdulmunib.ui.users;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import com.example.option1_inventoryapp_rayyanabdulmunib.R;
import com.example.option1_inventoryapp_rayyanabdulmunib.database.Database;
import com.example.option1_inventoryapp_rayyanabdulmunib.databinding.FragmentUsersBinding;
import java.util.List;

public class UsersFragment extends Fragment
{
    private FragmentUsersBinding binding;
    private Database database;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater)
    {
        inflater.inflate(R.menu.menu_inventory, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        int id = item.getItemId();
        if (id == R.id.action_add_item)
        {
            Navigation.findNavController(requireView()).navigate(R.id.navigation_register);
            return true;
        }

        else if (id == R.id.action_logout)
        {
            Navigation.findNavController(requireView()).navigate(R.id.navigation_login);
            return true;
        }

        else{}

        return super.onOptionsItemSelected(item);
    }

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_users, container, false);
        LinearLayout linearLayoutItems = view.findViewById(R.id.linear_layout_items2);

        // Initialize the database
        database = new Database(requireContext());

        // Retrieve list of users from the database
        List<User> userList = database.getAllUsers();

        // Populate users directly in the LinearLayout
        for (User user : userList)
        {
            View userView = inflater.inflate(R.layout.user_layout, null);

            // Find views in the inflated user layout and set item details
            TextView userEmail = userView.findViewById(R.id.userEmail);

            Button remove = userView.findViewById(R.id.btnRemove);

            userEmail.setText(user.getEmail());

            // Set click listener for each delete button
            remove.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    String email = userEmail.getText().toString().trim();

                    if (database != null)
                    {
                        database.deleteUser(email);
                        Toast.makeText(getContext(), "User deleted.", Toast.LENGTH_SHORT).show();
                        linearLayoutItems.removeView(userView);
                        database.getAllUsers();
                    }
                }
            });

            // Add the inflated user view to the LinearLayout
            linearLayoutItems.addView(userView);
        }

        return view;
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        binding = null;
    }
}