package com.example.option1_inventoryapp_rayyanabdulmunib.ui.register;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import com.example.option1_inventoryapp_rayyanabdulmunib.R;
import com.example.option1_inventoryapp_rayyanabdulmunib.database.Database;
import com.example.option1_inventoryapp_rayyanabdulmunib.databinding.FragmentRegisterBinding;

public class RegisterFragment extends Fragment
{
    private FragmentRegisterBinding binding;
    private Database database;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        // Access the activity's toolbar and disable the back button
        if (getActivity() != null)
        {
            ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
    }

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        database = new Database(requireContext());
        binding = FragmentRegisterBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Button registerButton = root.findViewById(R.id.register);
        registerButton.setOnClickListener(view ->
        {
            // Get entered username and email from EditText fields
            String enteredUsername = binding.setUsername.getText().toString().trim();
            String enteredPassword = binding.setPassword.getText().toString().trim();

            if (enteredUsername.isEmpty() || enteredPassword.isEmpty())
            {
                // Display an error message or prompt the user to fill in the required fields
                Toast.makeText(getContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show();
            }

            else
            {
                // Authenticate user
                boolean isAuthenticated = authenticateUser(enteredUsername);

                if (isAuthenticated == false)
                {
                    // Authentication successful, navigate to another fragment or activity
                    // For example, navigate to the home screen
                    // Replace R.id.fragment_container with your actual container ID
                    database.addUser(enteredUsername, enteredPassword);
                    Navigation.findNavController(requireView()).navigate(R.id.navigation_inventory);
                }

                else
                {
                    // Authentication failed, show an error message or take appropriate action
                    // For example, display an error toast
                    Toast.makeText(requireContext(), "An account with that email already exists.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button loginButton = root.findViewById(R.id.login);
        loginButton.setOnClickListener(view ->
        {
            Navigation.findNavController(requireView()).navigate(R.id.navigation_login);
        });

        return root;
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        binding = null;
    }
    private boolean authenticateUser(String username)
    {
        Database database = new Database(getActivity());
        SQLiteDatabase db = database.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE email = ?", new String[]{username});

        boolean userExists = cursor != null && cursor.getCount() > 0;

        if (cursor != null)
        {
            cursor.close();
        }

        else{}

        db.close();

        return userExists;
    }
}
