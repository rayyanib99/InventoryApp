package com.example.option1_inventoryapp_rayyanabdulmunib.ui.inventory;

public class Item
{
    private String itemName;
    private String itemDescription;
    private int quantity;
    private String imageURL;


    // Getters and Setters for itemName
    public String getItemName()
    {
        return itemName;
    }

    public void setItemName(String itemName)
    {
        this.itemName = itemName;
    }

    // Getters and Setters for itemDescription
    public String getItemDescription()
    {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription)
    {
        this.itemDescription = itemDescription;
    }

    // Getters and Setters for quantity
    public int getQuantity()
    {
        return quantity;
    }

    public void setQuantity(int quantity)
    {
        this.quantity = quantity;
    }

    // Getters and Setters for imageURL
    public String getImageURL()
    {
        return imageURL;
    }

    public void setImageURL(String imageURL)
    {
        this.imageURL = imageURL;
    }
}

