package com.example.option1_inventoryapp_rayyanabdulmunib.ui.notifications;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.Manifest;
import com.example.option1_inventoryapp_rayyanabdulmunib.R;
import com.example.option1_inventoryapp_rayyanabdulmunib.databinding.FragmentNotificationsBinding;

public class NotificationsFragment extends Fragment
{
    private FragmentNotificationsBinding binding;
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    private CheckBox checkPermission;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater)
    {
        inflater.inflate(R.menu.menu_inventory, menu);

        // Find the menu item by its ID
        MenuItem item = menu.findItem(R.id.action_add_item);
        item.setVisible(false);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        int id = item.getItemId();
        if (id == R.id.action_logout)
        {
            Navigation.findNavController(requireView()).navigate(R.id.navigation_login);
            return true;
        }

        else{}

        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View root = inflater.inflate(R.layout.fragment_notifications, container, false);

        checkPermission = root.findViewById(R.id.checkPermission);

        // Retrieve the saved preference and set the checkbox state accordingly
        SharedPreferences preferences = requireContext().getSharedPreferences("sms_pref", Context.MODE_PRIVATE);
        boolean allowSms = preferences.getBoolean("allow_sms", false);
        checkPermission.setChecked(allowSms);

        checkPermission.setOnClickListener(v ->
        {
            if (checkPermission.isChecked())
            {
                requestSmsPermission();
            }

            else
            {
                Toast.makeText(getContext(), "Saved preferences.", Toast.LENGTH_SHORT).show();
                saveSmsPreference(false);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        binding = null;
    }

    private void requestSmsPermission()
    {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }

        else
        {
            // Permission already granted, initiate SMS sending logic here
            saveSmsPreference(true);
            sendSMS();
        }
    }

    private void saveSmsPreference(boolean allowSms)
    {
        SharedPreferences preferences = requireContext().getSharedPreferences("sms_pref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("allow_sms", allowSms);
        editor.apply();
    }

    private void sendSMS()
    {
        String message = "New item added!";

        try
        {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("+1234567890", null, message, null, null);
            Toast.makeText(getContext(), "Saved preferences.", Toast.LENGTH_SHORT).show();
        }

        catch (SecurityException e)
        {
            Toast.makeText(getContext(), "Permission denied. SMS could not be sent.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            Toast.makeText(getContext(), "Saved preferences.", Toast.LENGTH_SHORT).show();
        }

        catch (Exception e)
        {
            Toast.makeText(getContext(), "SMS could not be sent.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}