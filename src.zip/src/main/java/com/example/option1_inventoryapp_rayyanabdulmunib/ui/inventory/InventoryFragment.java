package com.example.option1_inventoryapp_rayyanabdulmunib.ui.inventory;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import com.example.option1_inventoryapp_rayyanabdulmunib.R;
import com.example.option1_inventoryapp_rayyanabdulmunib.database.Database;
import com.example.option1_inventoryapp_rayyanabdulmunib.databinding.FragmentInventoryBinding;
import com.squareup.picasso.Picasso;

import java.util.List;

public class InventoryFragment extends Fragment
{
    private FragmentInventoryBinding binding;
    private Database database;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater)
    {
        inflater.inflate(R.menu.menu_inventory, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        int id = item.getItemId();
        if (id == R.id.action_add_item)
        {
            Navigation.findNavController(requireView()).navigate(R.id.navigation_addItem);
            return true;
        }

        else if (id == R.id.action_logout)
        {
            Navigation.findNavController(requireView()).navigate(R.id.navigation_login);
            return true;
        }

        else{}

        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_inventory, container, false);
        LinearLayout linearLayoutItems = view.findViewById(R.id.linear_layout_items);

        // Initialize the database
        database = new Database(requireContext());

        // Retrieve list of items from the database
        List<Item> itemList = database.getAllItems();

        // Populate items directly in the LinearLayout
        for (Item item : itemList)
        {
            View itemView = inflater.inflate(R.layout.item_layout, null);

            // Find views in the inflated item layout and set item details
            TextView itemName = itemView.findViewById(R.id.itemName);
            TextView itemDescription = itemView.findViewById(R.id.itemDescription);
            TextView itemQuantity = itemView.findViewById(R.id.itemQuantity);
            ImageView itemImage = itemView.findViewById(R.id.itemImage);
            Button delete = itemView.findViewById(R.id.btnDelete);
            Button add = itemView.findViewById(R.id.btnAdd);
            Button subtract = itemView.findViewById(R.id.btnSubtract);

            itemName.setText(item.getItemName());
            itemDescription.setText(item.getItemDescription());
            itemQuantity.setText(String.valueOf(item.getQuantity()));

            Picasso.get()
                    .load(item.getImageURL())
                    .placeholder(R.drawable.ic_image)
                    .error(R.drawable.ic_image)
                    .into(itemImage);

            // Set click listener for each delete button
            delete.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    String item = itemName.getText().toString().trim();

                    if (database != null)
                    {
                        database.deleteItem(item);
                        Toast.makeText(getContext(), "Item deleted.", Toast.LENGTH_SHORT).show();
                        linearLayoutItems.removeView(itemView);
                        database.getAllItems();
                    }
                }
            });

            // Set click listener for each delete button
            add.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    String item = itemName.getText().toString().trim();
                    int current_quantity = Integer.parseInt(itemQuantity.getText().toString().trim());

                    if (database != null)
                    {
                        database.updateItemQuantity(item, (current_quantity + 1));
                        itemQuantity.setText(Integer.toString(database.getItemQuantity(item)));
                        Toast.makeText(getContext(), "Inventory updated.", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            // Set click listener for each delete button
            subtract.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    String item = itemName.getText().toString().trim();
                    int current_quantity = Integer.parseInt(itemQuantity.getText().toString().trim());

                    if (database != null)
                    {
                        if(current_quantity != 0)
                        {
                            database.updateItemQuantity(item, (current_quantity - 1));
                            itemQuantity.setText(Integer.toString(database.getItemQuantity(item)));
                            Toast.makeText(getContext(), "Inventory updated.", Toast.LENGTH_SHORT).show();
                        }

                        else
                        {
                            Toast.makeText(getContext(), "Item out of stock.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });

            // Add the inflated item view to the LinearLayout
            linearLayoutItems.addView(itemView);
        }

        return view;
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        binding = null;
    }
}