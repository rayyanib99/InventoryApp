package com.example.option1_inventoryapp_rayyanabdulmunib.ui.inventory;

import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.Manifest;
import com.example.option1_inventoryapp_rayyanabdulmunib.R;
import com.example.option1_inventoryapp_rayyanabdulmunib.database.Database;
import com.example.option1_inventoryapp_rayyanabdulmunib.databinding.AddItemPopupBinding;

public class AddItem extends Fragment
{
    private AddItemPopupBinding binding;
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private Database database;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater)
    {
        inflater.inflate(R.menu.menu_inventory, menu);

        MenuItem item = menu.findItem(R.id.action_logout);
        item.setVisible(false);

        MenuItem item2 = menu.findItem(R.id.action_add_item);
        item2.setVisible(false);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        int id = item.getItemId();
        if (id == android.R.id.home)
        {
            Navigation.findNavController(requireView()).navigate(R.id.navigation_inventory);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        database = new Database(requireContext());
        View view = inflater.inflate(R.layout.add_item_popup, container, false);
        
        // Find your views
        EditText itemNameEditText = view.findViewById(R.id.item_name);
        EditText itemDescEditText = view.findViewById(R.id.item_description);
        EditText itemQuantEditText = view.findViewById(R.id.item_quantity);
        EditText itemImgEditText = view.findViewById(R.id.item_image);
        Button buttonAddItem = view.findViewById(R.id.action_add);

        buttonAddItem.setOnClickListener(v ->
        {
            String itemName = itemNameEditText.getText().toString().trim();
            String itemDescription = itemDescEditText.getText().toString().trim();
            String itemImage = itemImgEditText.getText().toString().trim();
            String itemQuantity = itemQuantEditText.getText().toString().trim();

            if (itemName.isEmpty() || itemDescription.isEmpty() || itemImage.isEmpty() || itemQuantity.isEmpty())
            {
                Toast.makeText(getContext(), "All fields are required.", Toast.LENGTH_SHORT).show();
            }

            else
            {
                if (authenticateItem(itemName))
                {
                    Toast.makeText(getContext(), "Item already exists.", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    database.addItem(itemName, itemDescription, Integer.parseInt(itemQuantity), itemImage);
                    Toast.makeText(getContext(), "Item added.", Toast.LENGTH_SHORT).show();
                    sendSMSIfNeeded(); // Check and send SMS if permission granted
                    Navigation.findNavController(requireView()).navigate(R.id.navigation_inventory);
                }
            }
        });

        return view;
    }

    private boolean authenticateItem(String item)
    {
        Database database = new Database(getActivity());
        SQLiteDatabase db = database.getReadableDatabase();

        boolean itemExists = false;

        try (Cursor cursor = db.rawQuery("SELECT * FROM items WHERE item_name = ?", new String[]{item}))
        {
            itemExists = cursor != null && cursor.getCount() > 0;
        }

        catch (Exception e)
        {
            e.printStackTrace();
        }

        finally
        {
            db.close();
        }

        return itemExists;
    }

    // Method to check SMS permission and send SMS if granted
    private void sendSMSIfNeeded()
    {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
        {
            // Permission not granted, request it
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }

        else
        {
            // Permission already granted, send SMS
            sendSMS();
        }
    }

    // Method to send an SMS
    private void sendSMS()
    {
        String message = "New item added!"; // Modify the message as needed

        try
        {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("+1234567890", null, message, null, null);
        }

        catch (SecurityException e)
        {
            Toast.makeText(getContext(), "Permission denied. SMS could not be sent.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        catch (Exception e)
        {
            Toast.makeText(getContext(), "SMS could not be sent.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        binding = null;
    }
}

