package com.example.option1_inventoryapp_rayyanabdulmunib.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.option1_inventoryapp_rayyanabdulmunib.ui.inventory.Item;
import com.example.option1_inventoryapp_rayyanabdulmunib.ui.users.User;
import java.util.ArrayList;
import java.util.List;

public class Database extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 12;

    // Table creation SQL statements
    private static final String CREATE_TABLE_USERS = "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, password TEXT)";
    private static final String CREATE_TABLE_ITEMS = "CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, item_name TEXT, item_description TEXT, item_quantity INTEGER, image_url TEXT)";
    public Database(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_ITEMS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("drop table if exists users");
        db.execSQL("drop table if exists items");
        onCreate(db);
    }

    // Create: Add a new item
    public long addItem(String itemName, String itemDesc, int itemQuantity, String imageURL)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_name", itemName);
        values.put("item_description", itemDesc);
        values.put("item_quantity", itemQuantity);
        values.put("image_url", imageURL);
        long newRowId = db.insert("items", null, values);
        db.close();
        return newRowId;
    }

    // Read: Retrieve all inventory items
    public List<Item> getAllItems()
    {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM items", null);

        if (cursor != null && cursor.moveToFirst())
        {
            int itemName = cursor.getColumnIndex("item_name");
            int itemDescription = cursor.getColumnIndex("item_description");
            int itemQuantity = cursor.getColumnIndex("item_quantity");
            int itemImage = cursor.getColumnIndex("image_url");

            do
            {
                // Check if column indices are valid before retrieving values for each iteration
                if (itemName >= 0 && itemDescription >= 0 && itemQuantity >= 0 && itemImage >= 0)
                {
                    Item item = new Item();
                    item.setItemName(cursor.getString(itemName));
                    item.setItemDescription(cursor.getString(itemDescription));
                    item.setQuantity(cursor.getInt(itemQuantity));
                    item.setImageURL(cursor.getString(itemImage));
                    itemList.add(item);
                }
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return itemList;
    }

    // Update updateItemQuantity method
    public int updateItemQuantity(String name, int newQuantity)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_quantity", newQuantity);
        int rowsAffected = db.update("items", values, "item_name=?", new String[]{String.valueOf(name)});
        db.close();
        return rowsAffected;
    }

    // Method to get the current item_quantity based on item name
    public int getItemQuantity(String itemName)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        int quantity = -1; // Set an initial value as -1 for validation purposes

        Cursor cursor = db.query("items", new String[]{"item_quantity"}, "item_name = ?", new String[]{itemName}, null, null, null);

        if (cursor != null && cursor.moveToFirst())
        {
            int quantityIndex = cursor.getColumnIndex("item_quantity");

            // Validate column index
            if (quantityIndex != -1)
            {
                quantity = cursor.getInt(quantityIndex);
            }

            cursor.close();
        }

        return quantity;
    }

    // Delete: Remove an item from inventory
    public void deleteItem(String name)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("items", "item_name=?", new String[]{String.valueOf(name)});
        db.close();
    }

    // Create: Add a new user
    public long addUser(String email, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("password", password);
        long newRowId = db.insert("users", null, values);
        db.close();
        return newRowId;
    }

    // Retrieve all users
    public List<User> getAllUsers()
    {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users", null);

        if (cursor != null && cursor.moveToFirst())
        {
            int emailIndex = cursor.getColumnIndex("email");
            int passwordIndex = cursor.getColumnIndex("password");

            do
            {
                User user = new User();

                // Check if column indices are valid before retrieving values
                if (emailIndex >= 0)
                {
                    user.setEmail(cursor.getString(emailIndex));
                }

                if (passwordIndex >= 0)
                {
                    user.setPassword(cursor.getString(passwordIndex));
                }

                userList.add(user);
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return userList;
    }

    // Delete: Remove a user by email
    public void deleteUser(String email)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = "email=?";
        String[] selectionArgs = {email};
        db.delete("users", selection, selectionArgs);
        db.close();
    }
}
