package com.example.option1_inventoryapp_rayyanabdulmunib;

import android.os.Bundle;
import android.view.View;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.example.option1_inventoryapp_rayyanabdulmunib.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity
{
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView bottomNavigationView = binding.navView;

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        navController.navigate(R.id.navigation_login);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.navigation_inventory, R.id.navigation_users, R.id.navigation_notifications).build();

        // Listen for destination changes in NavController
        navController.addOnDestinationChangedListener((controller, destination, arguments) ->
        {
            // Get the destination ID
            int destinationId = destination.getId();

            // Check if the current destination is the login screen
            boolean isLoginOrRegisterDestination = destinationId == R.id.navigation_login || destinationId == R.id.navigation_register;;

            // Set visibility based on the destination
            if (isLoginOrRegisterDestination)
            {
                bottomNavigationView.setVisibility(View.GONE);
            }

            else
            {
                bottomNavigationView.setVisibility(View.VISIBLE);
            }
        });

        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);
    }
}
